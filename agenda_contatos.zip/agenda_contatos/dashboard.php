<?php
require_once 'config.php';
requireLogin();

$pdo = getDB();
$usuario_id = $_SESSION['usuario_id'];
$busca = trim($_GET['busca'] ?? '');

// Conta total de contatos
$stmt = $pdo->prepare('SELECT COUNT(*) as total FROM contatos WHERE usuario_id = ?');
$stmt->execute([$usuario_id]);
$total = $stmt->fetch()['total'];

// Busca contatos
if ($busca !== '') {
    $stmt = $pdo->prepare("
        SELECT * FROM contatos 
        WHERE usuario_id = ? AND (
            nome LIKE ? OR telefone LIKE ? OR email LIKE ? OR empresa LIKE ?
        )
        ORDER BY nome ASC
    ");
    $termo = '%' . $busca . '%';
    $stmt->execute([$usuario_id, $termo, $termo, $termo, $termo]);
} else {
    $stmt = $pdo->prepare('SELECT * FROM contatos WHERE usuario_id = ? ORDER BY nome ASC');
    $stmt->execute([$usuario_id]);
}
$contatos = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard | Agenda de Contatos</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <nav class="navbar">
        <a href="dashboard.php" class="brand">
            <div class="icon">📒</div>
            Agenda de Contatos
        </a>
        <div class="user-menu">
            <span class="user-name">Olá, <?= e($_SESSION['usuario_nome']) ?></span>
            <a href="logout.php" class="btn btn-secondary btn-sm">Sair</a>
        </div>
    </nav>

    <div class="container">
        <div class="stats">
            <div class="stat-card">
                <div class="label">Total de contatos</div>
                <div class="value"><?= $total ?></div>
            </div>
        </div>

        <div class="page-header">
            <h1>Meus Contatos</h1>
            <div class="actions">
                <form method="GET" class="search-box">
                    <span class="search-icon">🔍</span>
                    <input type="text" name="busca" placeholder="Buscar por nome, telefone..." 
                           value="<?= e($busca) ?>">
                </form>
                <a href="contato.php" class="btn btn-primary">+ Novo Contato</a>
            </div>
        </div>

        <?php if (empty($contatos)): ?>
            <div class="empty-state">
                <div class="icon">📭</div>
                <h3><?= $busca ? 'Nenhum contato encontrado' : 'Nenhum contato ainda' ?></h3>
                <p><?= $busca ? 'Tente outro termo de busca.' : 'Comece adicionando seu primeiro contato!' ?></p>
                <?php if (!$busca): ?>
                    <a href="contato.php" class="btn btn-primary">Adicionar Contato</a>
                <?php endif; ?>
            </div>
        <?php else: ?>
            <div class="contacts-grid">
                <?php foreach ($contatos as $c): ?>
                    <div class="contact-card">
                        <div class="avatar"><?= strtoupper(mb_substr($c['nome'], 0, 1, 'UTF-8')) ?></div>
                        <h3><?= e($c['nome']) ?></h3>
                        <?php if ($c['empresa']): ?>
                            <div class="empresa"><?= e($c['empresa']) ?></div>
                        <?php endif; ?>
                        <div class="info">
                            <?php if ($c['telefone']): ?>
                                <div class="info-item">📞 <span><?= e($c['telefone']) ?></span></div>
                            <?php endif; ?>
                            <?php if ($c['email']): ?>
                                <div class="info-item">✉️ <span><?= e($c['email']) ?></span></div>
                            <?php endif; ?>
                            <?php if ($c['notas']): ?>
                                <div class="info-item">📝 <span><?= e(mb_strimwidth($c['notas'], 0, 60, '...', 'UTF-8')) ?></span></div>
                            <?php endif; ?>
                        </div>
                        <div class="actions">
                            <a href="contato.php?id=<?= $c['id'] ?>" class="btn btn-secondary btn-sm">Editar</a>
                            <a href="excluir.php?id=<?= $c['id'] ?>" class="btn btn-danger btn-sm"
                               onclick="return confirm('Tem certeza que deseja excluir este contato?')">Excluir</a>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </div>
</body>
</html>
