# Agenda de Contatos

Sistema de gestão de agenda de contatos com autenticação (login e senha).

## Tecnologias
- **PHP 8**
- **MySQL** (via PDO)
- **HTML5 + CSS3** (design moderno e responsivo)

## Funcionalidades
- Cadastro e login de usuários (senha com hash seguro)
- CRUD completo de contatos (criar, listar, editar, excluir)
- Busca por nome, telefone, e-mail ou empresa
- Interface moderna com cards e design responsivo
- Cada usuário vê apenas os próprios contatos

## Campos do contato
- Nome (obrigatório)
- Telefone
- E-mail
- Empresa
- Notas / Observações

---

## Como rodar no Laragon

1. **Copie a pasta** `agenda_contatos` para:
   ```
   C:\laragon\www\
   ```

2. **Inicie o Laragon** (botão Start All)

3. Acesse no navegador:
   - `http://agenda_contatos.test`
   - ou `http://localhost/agenda_contatos`

O sistema cria automaticamente o banco de dados `agenda_contatos` e as tabelas na primeira execução.

### Configuração do banco (opcional)

Se precisar alterar usuário/senha do MySQL, edite o arquivo `config.php`:

```php
define('DB_HOST', 'localhost');
define('DB_NAME', 'agenda_contatos');
define('DB_USER', 'root');
define('DB_PASS', '');          // Laragon padrão: senha vazia
```

---

## Estrutura de arquivos
```
agenda_contatos/
├── config.php       # Conexão MySQL + sessões
├── index.php        # Página de login
├── register.php     # Página de cadastro
├── dashboard.php    # Lista de contatos
├── contato.php      # Formulário de criar/editar
├── excluir.php      # Exclusão de contato
├── logout.php
├── style.css
└── README.md
```

## Segurança
- Senhas com `password_hash()` (bcrypt)
- Proteção XSS com `htmlspecialchars`
- Queries preparadas (PDO)
- Cada usuário só acessa seus próprios dados
