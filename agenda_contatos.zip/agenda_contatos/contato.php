<?php
require_once 'config.php';
requireLogin();

$pdo = getDB();
$usuario_id = $_SESSION['usuario_id'];
$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$erro = '';
$contato = null;

// Se for edição, carrega o contato
if ($id > 0) {
    $stmt = $pdo->prepare('SELECT * FROM contatos WHERE id = ? AND usuario_id = ?');
    $stmt->execute([$id, $usuario_id]);
    $contato = $stmt->fetch();
    
    if (!$contato) {
        header('Location: dashboard.php');
        exit;
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nome = trim($_POST['nome'] ?? '');
    $telefone = trim($_POST['telefone'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $empresa = trim($_POST['empresa'] ?? '');
    $notas = trim($_POST['notas'] ?? '');

    if (empty($nome)) {
        $erro = 'O nome é obrigatório.';
    } else {
        if ($id > 0) {
            // Atualiza
            $stmt = $pdo->prepare("
                UPDATE contatos 
                SET nome = ?, telefone = ?, email = ?, empresa = ?, notas = ?, atualizado_em = CURRENT_TIMESTAMP
                WHERE id = ? AND usuario_id = ?
            ");
            $stmt->execute([$nome, $telefone, $email, $empresa, $notas, $id, $usuario_id]);
        } else {
            // Insere
            $stmt = $pdo->prepare("
                INSERT INTO contatos (usuario_id, nome, telefone, email, empresa, notas)
                VALUES (?, ?, ?, ?, ?, ?)
            ");
            $stmt->execute([$usuario_id, $nome, $telefone, $email, $empresa, $notas]);
        }
        header('Location: dashboard.php');
        exit;
    }
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $id ? 'Editar' : 'Novo' ?> Contato | Agenda</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <nav class="navbar">
        <a href="dashboard.php" class="brand">
            <div class="icon">📒</div>
            Agenda de Contatos
        </a>
        <div class="user-menu">
            <span class="user-name">Olá, <?= e($_SESSION['usuario_nome']) ?></span>
            <a href="logout.php" class="btn btn-secondary btn-sm">Sair</a>
        </div>
    </nav>

    <div class="container">
        <div class="form-card">
            <h2><?= $id ? '✏️ Editar Contato' : '➕ Novo Contato' ?></h2>

            <?php if ($erro): ?>
                <div class="alert alert-error"><?= e($erro) ?></div>
            <?php endif; ?>

            <form method="POST">
                <div class="form-group">
                    <label for="nome">Nome *</label>
                    <input type="text" id="nome" name="nome" required
                           value="<?= e($_POST['nome'] ?? $contato['nome'] ?? '') ?>" autofocus>
                </div>
                <div class="form-group">
                    <label for="telefone">Telefone</label>
                    <input type="text" id="telefone" name="telefone" placeholder="(00) 00000-0000"
                           value="<?= e($_POST['telefone'] ?? $contato['telefone'] ?? '') ?>">
                </div>
                <div class="form-group">
                    <label for="email">E-mail</label>
                    <input type="email" id="email" name="email" placeholder="contato@email.com"
                           value="<?= e($_POST['email'] ?? $contato['email'] ?? '') ?>">
                </div>
                <div class="form-group">
                    <label for="empresa">Empresa</label>
                    <input type="text" id="empresa" name="empresa" placeholder="Nome da empresa"
                           value="<?= e($_POST['empresa'] ?? $contato['empresa'] ?? '') ?>">
                </div>
                <div class="form-group">
                    <label for="notas">Notas / Observações</label>
                    <textarea id="notas" name="notas" placeholder="Anotações sobre o contato..."><?= e($_POST['notas'] ?? $contato['notas'] ?? '') ?></textarea>
                </div>
                <div class="form-actions">
                    <a href="dashboard.php" class="btn btn-secondary">Cancelar</a>
                    <button type="submit" class="btn btn-primary"><?= $id ? 'Salvar' : 'Adicionar' ?></button>
                </div>
            </form>
        </div>
    </div>
</body>
</html>
