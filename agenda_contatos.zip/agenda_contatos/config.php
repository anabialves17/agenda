<?php
// ============================================
// CONFIGURAÇÃO DO BANCO DE DADOS - MySQL (Laragon)
// ============================================
// Altere esses dados se necessário
define('DB_HOST', 'localhost');
define('DB_NAME', 'agenda_contatos');
define('DB_USER', 'root');
define('DB_PASS', '');          // No Laragon a senha do root costuma ser vazia
define('DB_CHARSET', 'utf8mb4');

// Inicia a sessão
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Função para conectar ao banco
function getDB() {
    static $pdo = null;
    
    if ($pdo === null) {
        try {
            $dsn = 'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=' . DB_CHARSET;
            $pdo = new PDO($dsn, DB_USER, DB_PASS, [
                PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES   => false,
            ]);
        } catch (PDOException $e) {
            // Se o banco ainda não existir, tenta criar
            if ($e->getCode() == 1049) { // Unknown database
                try {
                    $pdoTemp = new PDO('mysql:host=' . DB_HOST . ';charset=' . DB_CHARSET, DB_USER, DB_PASS);
                    $pdoTemp->exec("CREATE DATABASE IF NOT EXISTS `" . DB_NAME . "` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
                    $pdoTemp = null;
                    
                    // Conecta novamente
                    $dsn = 'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=' . DB_CHARSET;
                    $pdo = new PDO($dsn, DB_USER, DB_PASS, [
                        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
                        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                        PDO::ATTR_EMULATE_PREPARES   => false,
                    ]);
                } catch (PDOException $e2) {
                    die('Erro ao criar o banco de dados: ' . $e2->getMessage());
                }
            } else {
                die('Erro de conexão: ' . $e->getMessage());
            }
        }
    }
    
    return $pdo;
}

// Cria as tabelas se não existirem
function initDB() {
    $pdo = getDB();
    
    // Tabela de usuários
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS usuarios (
            id INT AUTO_INCREMENT PRIMARY KEY,
            nome VARCHAR(100) NOT NULL,
            email VARCHAR(150) NOT NULL UNIQUE,
            senha VARCHAR(255) NOT NULL,
            criado_em DATETIME DEFAULT CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
    ");
    
    // Tabela de contatos
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS contatos (
            id INT AUTO_INCREMENT PRIMARY KEY,
            usuario_id INT NOT NULL,
            nome VARCHAR(100) NOT NULL,
            telefone VARCHAR(30) DEFAULT NULL,
            email VARCHAR(150) DEFAULT NULL,
            empresa VARCHAR(100) DEFAULT NULL,
            notas TEXT DEFAULT NULL,
            criado_em DATETIME DEFAULT CURRENT_TIMESTAMP,
            atualizado_em DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
    ");
}

// Inicializa o banco e tabelas
initDB();

// Função de autenticação
function isLoggedIn() {
    return isset($_SESSION['usuario_id']);
}

// Redireciona se não estiver logado
function requireLogin() {
    if (!isLoggedIn()) {
        header('Location: index.php');
        exit;
    }
}

// Função para sanitizar saída
function e($str) {
    return htmlspecialchars($str ?? '', ENT_QUOTES, 'UTF-8');
}
?>
