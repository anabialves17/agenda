<?php
require_once 'config.php';
requireLogin();

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

if ($id > 0) {
    $pdo = getDB();
    $stmt = $pdo->prepare('DELETE FROM contatos WHERE id = ? AND usuario_id = ?');
    $stmt->execute([$id, $_SESSION['usuario_id']]);
}

header('Location: dashboard.php');
exit;
?>
